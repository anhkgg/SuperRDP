SuperRDP2：

作者：汉客儿，欢迎关注公众号：汉客儿
author：anhkgg

官网：https://www.hankeer.org

git：https://github.com/anhkgg/SuperRDP
中文帮助：https://github.com/anhkgg/SuperRDP/blob/main/superrdp2_help_cn.md
help：https://github.com/anhkgg/SuperRDP/blob/main/superrdp2_help.md
